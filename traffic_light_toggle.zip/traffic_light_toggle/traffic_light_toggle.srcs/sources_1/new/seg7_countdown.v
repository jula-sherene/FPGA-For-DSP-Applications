`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 09:34:10 PM
// Design Name: 
// Module Name: seg7_countdown
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
// Shows the seconds remaining in the current traffic light state on ONE
// 7-segment digit, counting down to 0 right as the state switches.
// Pure combinational logic -- reuses elapsed_sec from the FSM, no new
// counter, no clock, no multiplexing (single digit, standard 0-9 shapes).
//////////////////////////////////////////////////////////////////////////////////


module seg7_countdown(
input wire [1:0] state,
    input wire [3:0] elapsed_sec,
    output wire [7:0] AN,
    output wire CA, CB, CC, CD, CE, CF, CG,
    output wire         DP
    );
    
    localparam [1:0] S_GREEN = 2'd0;
    localparam [1:0] S_BLUE = 2'd1;
    localparam [1:0] S_RED = 2'd2;
    
    localparam [3:0] S_GREEN_TIME = 4'd10;
    localparam [3:0] S_BLUE_TIME = 4'd3;
    localparam [3:0] S_RED_TIME = 4'd7;
    
    // Total duration of whichever state is currently active, minus 1
    wire [3:0] target_max = (state == S_GREEN) ? (S_GREEN_TIME - 1) :
                                (state == S_BLUE) ? (S_BLUE_TIME - 1):
                                                    (S_RED_TIME - 1);
                                                    
    // Counts down: 9,8,...,0 for green; 2,1,0 for blue; 6,...,0 for red
    wire [3:0] remaining = target_max - elapsed_sec;
    
    // Standard 7-segment digit patterns, bit order {a,b,c,d,e,f,g}, 1=on
    //eg: whose pattern is 0110011 in the order a, b, c, d, e, f, g: a=0, so no top line, b=1, so upper-right on, c=1, so lower-right on, 
    //d=0, so no bottom line, d=0, so no bottom line, e=0, so no lower-left, f=1, so upper-left on, g=1, so middle on
  //  ─── a ───         
  // |         |
 //  f         b
 //  |         |
 //   ─── g ───
 //  |         |
 //  e         c
 //  |         |
 //   ─── d ───
    reg [6:0] pattern;
    always @* begin
        case (remaining)
            4'd0: pattern = 7'b1111110;
            4'd1: pattern = 7'b0110000;
            4'd2: pattern = 7'b1101101;
            4'd3: pattern = 7'b1111001;
            4'd4: pattern = 7'b0110011;
            4'd5: pattern = 7'b1011011;
            4'd6: pattern = 7'b1011111;
            4'd7: pattern = 7'b1110000;
            4'd8: pattern = 7'b1111111;
            4'd9: pattern = 7'b1111011;
            default: pattern = 7'b0000000;
         endcase
     end
     
     assign AN = 8'b11111110; // only the rightmost digit enabled 1 means OFF
     assign {CA, CB, CC, CD, CE, CF, CG} = ~pattern;
     assign DP = 1'b1;
     
endmodule
