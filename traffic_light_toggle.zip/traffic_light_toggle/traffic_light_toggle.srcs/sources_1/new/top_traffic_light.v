`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/21/2026 09:37:05 PM
// Design Name: 
// Module Name: top_traffic_light
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module top_traffic_light #(
    // 100MHz clock ticks that make up one real second
    parameter integer TICK_DIV = 100_000_000
)(
    input  wire        CLK100MHZ,
    input  wire        CPU_RESETN,
    output wire         LED16_R, LED16_G, LED16_B,
    output wire [7:0]  AN,
    output wire         CA, CB, CC, CD, CE, CF, CG,
    output wire         DP
);

// FSM
// States: 00, 01, 10 in BIN OR 0, 1, 2 in Dec
    localparam [1:0] S_GREEN = 2'd0;
    localparam [1:0] S_BLUE  = 2'd1;
    localparam [1:0] S_RED   = 2'd2;

//  Time: Green 10, Blue 3, Red = 7 
    localparam [3:0] GREEN_TIME = 4'd10;
    localparam [3:0] BLUE_TIME  = 4'd3;
    localparam [3:0] RED_TIME   = 4'd7;

//  2-bit register, starting at green.
    reg [1:0] state       = S_GREEN;
//  4-bit register, counting seconds of the current color from 0.
    reg [3:0] elapsed_sec = 4'd0;
//  27-bit register counting clock ticks, starting at 0.
    reg [26:0] tick_counter = 27'd0;
//  checks that becomes 1, 1 sec has just been counted
    wire       tick_1hz     = (tick_counter == TICK_DIV - 1);

    always @(posedge CLK100MHZ or negedge CPU_RESETN) begin
        if (!CPU_RESETN) // RESET Button is pressed means it drops to 0
            tick_counter <= 27'd0; 
        else if (tick_1hz) //If the condition counter just reached its target it drops to 0
            tick_counter <= 27'd0;
        else
            tick_counter <= tick_counter + 1'b1; //add 1 to the counter 
    end

// this block runs on every clock tick or if reset is pressed.
    always @(posedge CLK100MHZ or negedge CPU_RESETN) begin 
        if (!CPU_RESETN) begin //if the reset button 
            state       <= S_GREEN; //it starts from state green LED
            elapsed_sec <= 4'd0; //counter starts from 0
        end else if (tick_1hz) begin //FSM's decisions happen once a sec
            case (state)
                S_GREEN: if (elapsed_sec == GREEN_TIME - 1) begin //10th tick, elapsed = 9 
                             state <= S_BLUE; elapsed_sec <= 4'd0;
                         end else begin
                             elapsed_sec <= elapsed_sec + 1'b1; //it increments
                         end
                S_BLUE:  if (elapsed_sec == BLUE_TIME - 1) begin //3rd tick, elapsed = 2
                             state <= S_RED; elapsed_sec <= 4'd0;
                         end else begin
                             elapsed_sec <= elapsed_sec + 1'b1;
                         end
                S_RED:   if (elapsed_sec == RED_TIME - 1) begin //7th tick, elapsed = 6
                             state <= S_GREEN; elapsed_sec <= 4'd0;
                         end else begin
                             elapsed_sec <= elapsed_sec + 1'b1;
                         end
                default: begin
                             state <= S_GREEN; elapsed_sec <= 4'd0; //Begin from green 
                         end
            endcase
        end
    end

    assign LED16_G = (state == S_GREEN);
    assign LED16_B = (state == S_BLUE);
    assign LED16_R = (state == S_RED);

    seg7_countdown disp (
        .state       (state),
        .elapsed_sec (elapsed_sec),
        .AN          (AN),
        .CA (CA), .CB (CB), .CC (CC), .CD (CD),
        .CE (CE), .CF (CF), .CG (CG),
        .DP          (DP)
    );
endmodule
